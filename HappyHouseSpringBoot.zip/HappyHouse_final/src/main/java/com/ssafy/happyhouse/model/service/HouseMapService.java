package com.ssafy.happyhouse.model.service;

public interface HouseMapService {
	
	String dongCode(String dongName) throws Exception;
}
