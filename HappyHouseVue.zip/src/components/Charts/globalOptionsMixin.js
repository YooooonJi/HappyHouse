import { initGlobalOptions } from "@/components/Charts/config";
import './roundedCornersExtension'
export default {
  mounted() {
    initGlobalOptions();
  }
}
