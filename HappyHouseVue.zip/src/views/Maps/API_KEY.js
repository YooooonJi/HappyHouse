export const API_KEY = 'AIzaSyBpOUzAWA7byDGSoAtviKha58KGGyCyFtI';
